#!/bin/sh
ln -sf /mnt/data/wireguard/usr/bin/wg-quick /usr/bin
ln -sf /mnt/data/wireguard/usr/bin/wg /usr/bin
ln -sf /mnt/data/wireguard/usr/bin/bash /usr/bin
ln -sf /mnt/data/wireguard/usr/bin/qrencode /usr/bin
ln -sf /mnt/data/wireguard/usr/bin/htop /usr/bin
ln -sf /mnt/data/wireguard/usr/sbin/iftop /usr/sbin

# create symlink to wireguard config folder
if [ ! -d "/etc/wireguard" ]
then
   ln -s /mnt/data/wireguard/etc/wireguard /etc/wireguard
fi

# required by wg-quick
if [ ! -d "/dev/fd" ]
then
   ln -s /proc/self/fd /dev/fd
fi

#load dependant modules
modprobe udp_tunnel
modprobe ip6_udp_tunnel

lsmod|egrep ^wireguard > /dev/null 2>&1
if [ $? -eq 1 ]
then
   ver=`uname -r`
   echo "loading wireguard..."
   insmod wireguard-$ver.ko
# iptable_raw required for wg-quick's use of iptables-restore
   insmod iptable_raw-$ver.ko
fi
