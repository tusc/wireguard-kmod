#!/bin/sh
ln -s /mnt/data/wireguard/usr/bin/wg-quick /usr/bin > /dev/null 2>&1
ln -s /mnt/data/wireguard/usr/bin/wg /usr/bin > /dev/null 2>&1
ln -s /mnt/data/wireguard/usr/bin/bash /usr/bin > /dev/null 2>&1

# create symlink to wireguard config folder
if [ ! -d "/etc/wireguard" ]
then
   ln -s /mnt/data/wireguard/etc/wireguard /etc/wireguard > /dev/null 2>&1
fi

# required by wg-quick
if [ ! -d "/dev/fd" ]
then
   ln -s /proc/self/fd /dev/fd &>/dev/null > /dev/null 2>&1
fi

#load dependant modules
modprobe udp_tunnel
modprobe ip6_udp_tunnel

lsmod|egrep ^wireguard > /dev/null 2>&1
if [ $? -eq 1 ]
then
   ver=`uname -r`
   echo "loading wireguard..."
   insmod wireguard-$ver.ko
fi
